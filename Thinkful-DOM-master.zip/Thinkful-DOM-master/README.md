Thinkful example exercise to get to know the DOM
=================================================


Download this and follow the instructions on the course.

